import React from 'react'

const SampleSurvey = () => {
    return (
        <div><h2>Sample Survey</h2></div>
    );
};

export default SampleSurvey;