# Alternate solution to Advanced Practice - Surveys

The solution in the directory above follows the coding walkthrough videos that
accompany this project. The videos, however, create the project using
`create-react-app` and use old versions of React and React Router. They also
leave several parts of the project for students to complete on their own. The
corresponding solution is accordingly both outdated and incomplete.

This directory supplies a full, Vite-based alternative solution unrelated to the
video-based version. To view this full version, simply run `npm install` in this
directory. Once all of the dependencies are installed, `npm run dev` will run
the app.
