import './HomePage.css';

function HomePage() {
  return (
    <>
      <h2>Fill out Customized Surveys</h2>
      <div className="description">
        Choose a survey to fill out and see results for sample customized
        surveys.
      </div>
    </>
  );
}

export default HomePage;
