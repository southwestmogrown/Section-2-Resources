import SurveyPage from './SurveyPage';

export default SurveyPage;
