export default function NotFoundPage() {
  return <h1>Page Not Found</h1>
}
