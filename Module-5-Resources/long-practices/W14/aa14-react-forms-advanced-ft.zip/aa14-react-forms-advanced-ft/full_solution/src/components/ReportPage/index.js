import ReportPage from './ReportPage';

export default ReportPage;
