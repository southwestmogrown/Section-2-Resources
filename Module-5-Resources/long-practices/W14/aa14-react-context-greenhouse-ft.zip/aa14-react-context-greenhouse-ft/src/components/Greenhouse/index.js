import Greenhouse from './Greenhouse';

export default Greenhouse;
