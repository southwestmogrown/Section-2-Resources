// To see the Form with Bonus features implemented, comment out the first two
// imports below and comment in the latter two.
import './index.css';
import Form from './components/Form';
// import './indexBonus.css';
// import Form from './components/FormBonus';

function App() {
  return <Form />;
}

export default App;
