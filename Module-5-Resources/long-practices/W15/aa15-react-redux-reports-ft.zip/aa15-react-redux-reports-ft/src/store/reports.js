import initialReports from '../data/initial-reports.json';
import { createSelector } from 'reselect';

export const RECEIVE_REPORT = 'reports/RECEIVE_REPORT';
export const REMOVE_REPORT = 'reports/REMOVE_REPORT';
export const RESET_REPORTS = 'reports/RESET_REPORTS';

export const receiveReport = report => ({
  type: RECEIVE_REPORT,
  report
});

export const removeReport = reportId => ({
  type: REMOVE_REPORT,
  reportId
});

export const resetReports = () => ({
  type: RESET_REPORTS
});

const selectReports = state => state?.reports;

export const selectAllReports = createSelector (selectReports, (reports) => {
  return reports ? Object.values(reports) : [];
});

export const selectReport = reportId => state => {
  return state?.reports ? state.reports[reportId] : null;
};

const initialState = {};
initialReports.forEach(report => {
  initialState[report.id] = report;
});

const reportsReducer = (state = initialState, action) => {
  switch (action.type) {
    case RECEIVE_REPORT:
      return { ...state, [action.report.id]: action.report };
    case REMOVE_REPORT: {
      const newState = { ...state };
      delete newState[action.reportId];
      return newState;
    }
    case RESET_REPORTS:
      return initialState;
    default:
      return state;
  }
};

export default reportsReducer;
