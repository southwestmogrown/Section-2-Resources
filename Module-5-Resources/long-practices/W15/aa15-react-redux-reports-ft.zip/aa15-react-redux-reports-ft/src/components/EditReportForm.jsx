import { useParams } from 'react-router-dom';
import ReportForm from './ReportForm';
import { useSelector } from 'react-redux';
import { selectReport } from '../store/reports';

const EditReportForm = () => {
  const { reportId } = useParams();
  const report = useSelector(selectReport(reportId));

  return (
    <ReportForm report={report} formType="Update Report" />
  );
}

export default EditReportForm;
