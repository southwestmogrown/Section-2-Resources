import GalleryNavigation from './GalleryNavigation';

export default GalleryNavigation;
