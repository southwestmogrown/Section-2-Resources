import GalleryView from './GalleryView';

export default GalleryView;
