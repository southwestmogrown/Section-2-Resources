import ArtDescription from './ArtDescription';

export default ArtDescription;
