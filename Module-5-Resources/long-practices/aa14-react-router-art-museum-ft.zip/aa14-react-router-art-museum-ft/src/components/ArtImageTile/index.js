import ArtImageTile from './ArtImageTile';

export default ArtImageTile;
