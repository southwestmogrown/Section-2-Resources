-- Find the name and birth year of all the cats ordered by descending birth year
SELECT name, birth_year
FROM cats
ORDER BY birth_year DESC;
