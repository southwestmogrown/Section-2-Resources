# Phase 2 - before edits

npx dotenv sequelize seed:generate --name biggest-trees
