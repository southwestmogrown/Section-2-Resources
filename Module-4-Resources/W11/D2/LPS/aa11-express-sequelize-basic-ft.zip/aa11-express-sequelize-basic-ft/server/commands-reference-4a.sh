# Phase 2 - before edits

npx dotenv sequelize seed:generate --name smallest-insects
