tweets= [
    { 
        
        "id": 1,
        "author": "Elon Musk",
        "date": "12/4/22",
        "tweet": "Anything anyone says will be used against me in a court of law",
        "likes": 504_000,
    },
    { 
        "id": 2,
        "author": "Elon Musk",
        "date": "12/3/22",
        "tweet": "Twitter servers are running at Warp 9!!",
        "likes": 527_000,
    },
    { 
        "id": 3,
        "author": "Elon Musk",
        "date": "12/2/22",
        "tweet": "You know Twitter is being fair when extremists on far right and far left are simultaneously upset!  Twitter aims to serve center 80% of people, who wish to learn, laugh & engage in reasoned debate. ❤️",
        "likes": 510_900,
    },
    { 
        "id": 3,
        "author": "Elon Musk",
        "date": "4/15/19",
        "tweet": "I was always crazy on Twitter fyi",
        "likes": 76_600,
    },
    { 
        "id": 4,
        "author": "Elon Musk",
        "date": "12/12/19",
        "tweet": "If life is a video game, the graphics are great, but the plot is confusing & the tutorial is way too long",
        "likes": 695_500,
    },
]

